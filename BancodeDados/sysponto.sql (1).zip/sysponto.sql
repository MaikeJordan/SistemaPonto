-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: Jun 22, 2015 as 02:45 PM
-- Versão do Servidor: 5.1.33
-- Versão do PHP: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `sysponto`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `bancodehoras`
--

CREATE TABLE IF NOT EXISTS `bancodehoras` (
  `bancodehorasid` int(11) NOT NULL AUTO_INCREMENT,
  `horas` int(11) DEFAULT NULL,
  `pontoid` int(11) DEFAULT NULL,
  PRIMARY KEY (`bancodehorasid`),
  KEY `pontoid` (`pontoid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `bancodehoras`
--


-- --------------------------------------------------------

--
-- Estrutura da tabela `funcionario`
--

CREATE TABLE IF NOT EXISTS `funcionario` (
  `funcionarioid` int(11) NOT NULL AUTO_INCREMENT,
  `nome` varchar(200) NOT NULL,
  `cpf` varchar(12) NOT NULL,
  `salario` double NOT NULL,
  `cargahoraria` int(11) NOT NULL,
  `status` int(1) DEFAULT '0',
  `email` varchar(30) DEFAULT NULL,
  `identidade` varchar(30) DEFAULT NULL,
  `login` varchar(25) DEFAULT NULL,
  `senha` varchar(32) DEFAULT NULL,
  PRIMARY KEY (`funcionarioid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Extraindo dados da tabela `funcionario`
--

INSERT INTO `funcionario` (`funcionarioid`, `nome`, `cpf`, `salario`, `cargahoraria`, `status`, `email`, `identidade`, `login`, `senha`) VALUES
(7, 'Cristiano Ronaldo', '183.781.237-', 827489, 28374892, 0, 'andersonrdm17@hotmail.com', '87238', 'andersonbk17', '202cb962ac59075b964b07152d234b70'),
(6, 'Maike', '12061177611', 1222, 40, 1, 'maikejordan@gmail.com', '17.830.836', 'maike', '202cb962ac59075b964b07152d234b70'),
(8, 'Arley', '111.111.111-', 3000, 80, 0, 'arley@gmail.com', '11111111', 'arley', '202cb962ac59075b964b07152d234b70'),
(9, 'Gustavo', '112.312.111-', 1111, 80, 0, 'gustavo@hotmail.com', '11111111', 'gustavo', '202cb962ac59075b964b07152d234b70'),
(10, 'Rodrigo Bastista', '111.111.111-', 1111, 80, 0, 'rodrigo@hotmail.com', '11111111', 'rodrigo', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Estrutura da tabela `ponto`
--

CREATE TABLE IF NOT EXISTS `ponto` (
  `pontoid` int(11) NOT NULL AUTO_INCREMENT,
  `horaEntrada` time DEFAULT NULL,
  `horaAlmoco` time DEFAULT NULL,
  `horaAlmocoVolta` time DEFAULT NULL,
  `horaSaida` time DEFAULT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `funcionarioid` int(11) DEFAULT NULL,
  PRIMARY KEY (`pontoid`),
  KEY `funcionarioid` (`funcionarioid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=62 ;

--
-- Extraindo dados da tabela `ponto`
--

INSERT INTO `ponto` (`pontoid`, `horaEntrada`, `horaAlmoco`, `horaAlmocoVolta`, `horaSaida`, `data`, `funcionarioid`) VALUES
(8, '12:18:04', '16:56:33', '17:27:51', '17:33:44', '2015-06-19 12:18:06', 7),
(10, '13:43:42', '18:11:31', '18:11:33', '18:11:35', '2015-06-19 13:43:43', 6),
(61, '13:55:26', '14:34:47', '14:34:56', '14:35:04', '2015-06-22 13:55:28', 9),
(60, '13:30:18', '13:30:32', NULL, NULL, '2015-06-22 13:30:21', 8),
(59, NULL, NULL, NULL, NULL, '2015-06-22 09:42:45', NULL),
(58, '00:48:47', '00:48:52', '00:48:53', '00:48:54', '2015-06-22 00:48:49', 6),
(57, '13:19:07', '13:19:10', '13:19:11', '13:19:11', '2015-06-21 13:19:10', 8),
(56, '13:15:50', '13:15:55', '13:15:57', '13:15:58', '2015-06-21 13:15:55', 6),
(55, '23:00:57', '23:01:00', '23:01:05', '23:01:06', '2015-06-20 23:01:00', 10),
(54, '19:03:56', '19:03:56', '19:59:40', '20:06:43', '2015-06-20 19:04:57', 9),
(49, '19:06:56', '19:07:04', '19:07:12', '19:07:19', '2015-06-19 19:07:04', 8);

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE IF NOT EXISTS `usuario` (
  `usuarioid` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(200) NOT NULL,
  `senha` varchar(200) NOT NULL,
  `status` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`usuarioid`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Extraindo dados da tabela `usuario`
--

